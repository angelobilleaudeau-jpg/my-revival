# MTB REVIVALS

A standalone Roblox-inspired revival frontend with a 2019-era visual direction.

## Included
- Home, Games, Catalog, Avatar, Inventory and News
- Login and signup
- 1,000 starting MTB Coins
- Persistent browser accounts/inventory using localStorage
- Buy confirmation, free-item confirmation, inventory and avatar equipment
- Maximum 3 equipped accessories
- Responsive mobile layout

## Run
Open `index.html` in a browser or deploy the folder to GitHub Pages.

## Important
This package is a frontend/demo. It does not connect to Roblox's private backend and does not provide real Roblox accounts or authentication. For real multi-user persistence and multiplayer games, add a server/API and database.
